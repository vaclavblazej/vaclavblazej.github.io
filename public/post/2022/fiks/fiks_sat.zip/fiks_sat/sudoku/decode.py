#!/usr/bin/env python3

import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common
import math

numbers = common.load_sat_solution()

n = 9

mapping = common.RangeMap([9,9,9])

arr = [[0 for i in range(9)] for j in range(9)]
for i, n in enumerate(numbers):
    if n > 0:
        [x, y, val] = mapping.decode(i)
        arr[y][x] = val

for v in arr:
    for n in v:
        print(n+1, end='')
    print()
