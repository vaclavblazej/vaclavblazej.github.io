# Úloha 'Řešič Sudoku'

## Zadání

Vyřeste sudoku.

## Vstup

Soubor s devíti řádky, každý s devíti čísly v rozsahu 0-9.
Nuly reprezentují nevyplněné políčko.
Soubor se předá do programu `sudoku.sh` v argumentu.

## Výstup 

Stejný jako vstup, jen v něm nesmí být nuly.

## Řešení

Proměnné za to jestli na políčku F je číslo A.
Na políčku nesmí být více čísel zároveň.
Pro každou dvojici nekompatibilních stejných hodnot (řádky, sloupce, 3x3 čtverce) se vytvoří zakazující klauzule.
Předvyplněná pole se nastaví na TRUE.

Celkový počet klauzulí je zhruba 3^7.

Následně se zavolá MiniSat a řešení se transformuje na žádaný výstup.

## Autoři

* Václav Blažej
