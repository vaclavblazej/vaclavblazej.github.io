#!/usr/bin/env python3

import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common

def generate_all_points(n):
    all_points = []
    for i in range(n):
        for j in range(n):
            for val in range(n):
                all_points.append((i, j, val))
    return all_points

def generate_clause(p, q):
    if p == q:
        return False
    px, py, pv = p
    qx, qy, qv = q
    return (pv == qv and (px == qx or py == qy or ((px//3 == qx//3) and (py//3 == qy//3)))) or (pv != qv and px == qx and py == qy)

def generate_claueses(filename):
    mapping = common.RangeMap([9,9,9])
    all_points = generate_all_points(9)
    clauses = []
    for p in all_points:
        for q in all_points:
            if generate_clause(p, q):
                clauses.append([-mapping.encode(p), -mapping.encode(q)])
    for i in range(9):
        for j in range(9):
            clause = []
            for val in range(9):
                clause.append(mapping.encode([i, j, val]))
            clauses.append(clause)
    for lineno, line in enumerate(open(filename, "r")):
        for charno, c in enumerate(line):
            if c != '0' and c != '\n':
                clauses.append([mapping.encode([charno, lineno, ord(c)-ord('1')])])
    return clauses

def main():
    filename = sys.argv[1]
    clauses = generate_claueses(filename)
    common.print_clauses(clauses)

if __name__ == '__main__':
    main()
