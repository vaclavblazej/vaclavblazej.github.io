#!/usr/bin/env python3

import sys
import itertools

class RangeMap:
    def __init__(self, ranges):
        self.ranges = ranges
        self.multiples = []
        val = 1
        for rng in self.ranges:
            self.multiples.append(val)
            val *= rng

    def encode(self, values):
        res = 1
        for i, val in enumerate(values):
            res += self.multiples[i] * val
        return res

    def decode(self, val):
        val -= 1
        res = []
        for mult in reversed(self.multiples):
            r = val // mult
            val -= r * mult
            res.append(r)
        return list(reversed(res))

    def to_int(self, values):
        ''' << deprecated >> '''
        res = 1
        for i, val in enumerate(values):
            res += self.multiples[i] * val
        return res

def print_clauses(clauses):
    variables = 0
    for clause in clauses:
        for var in clause:
            variables = max(variables, abs(var))
    print('p cnf', variables, len(clauses))
    for clause in clauses:
        print(*clause, 0)

def load_graph():
    (n, m) = map(int, input().split(' '))
    graph = []
    for i in range(n):
        graph.append([])
    for i in range(m):
        (f, t) = map(int, input().split(' '))
        f -= 1
        t -= 1
        graph[f].append(t)
        graph[t].append(f)
    return graph

def load_zero_graph():
    (n, m) = map(int, input().split(' '))
    graph = []
    for i in range(n):
        graph.append([])
    for i in range(m):
        (f, t) = map(int, input().split(' '))
        graph[f].append(t)
        graph[t].append(f)
    return graph

def load_automaton():
    [n] = map(int, input().split(' '))
    automaton = []
    for i in range(n):
        automaton.append([])
    for i in range(n):
        [zero, one] = map(int, input().split(' '))
        automaton[i].append(zero)
        automaton[i].append(one)
    return automaton

def one_hot(variables):
    return [variables] + list(itertools.combinations(map(lambda x:-x,variables), 2))

def load_sat_solution():
    result = input()
    print(result, file=sys.stderr)
    if result != "SAT":
        exit(0)
    return [0] + [int(i) for i in input().split()]
