#!/usr/bin/env bash

cd "$(dirname "$0")" || exit

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 size_of_the_board" >&2
    exit 1
fi

../MiniSat_v1.14_linux <(python3 encode.py "$1") >(python3 decode.py)

exit 0
