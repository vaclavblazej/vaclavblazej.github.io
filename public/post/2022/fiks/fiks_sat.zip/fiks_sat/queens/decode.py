#!/usr/bin/env python3

import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common
import math

numbers = common.load_sat_solution()

N = int(math.sqrt(len(numbers)))

mapping = common.RangeMap([N,N])
arr = [[0 for i in range(N)] for j in range(N)]

for i, n in enumerate(numbers):
    if n > 0:
        [x, y] = mapping.decode(i)
        arr[y][x] = 1

for i in range(N):
    row = ""
    for j in range(N):
        row += str(arr[i][j])
    print(row)
