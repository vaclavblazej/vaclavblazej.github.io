# Úloha 'Neohrožující se královny na šachovnici' z UMI cvičení 3

## Zadání

Mějme šachovnici velikosti NxN.
Lze na ni umístit N královen tak, aby se žádné dvě neohrožovaly?

## Vstup

Jediné číslo N (velikost šachovnice), které se předá jako argument programu `queens.sh`.

## Výstup 

Grid 1 a 0, kde 1 znamená, že na daném políčku se nachází královna.

## Řešení

Vytvoří se klauzule určující, že v každém řádku musí být alespoň jedna královna a dále se vytvoří klauzule, které říkají, že nesmí existotvat 2 královny, které se navzájemn ohrožují.
Celková složitost O(N^4).

Následně se zavolá MiniSat a řešení se transformuje na výstupní grid.

## Autoři

* Jan Pokorný -- řešení
* Václav Blažej -- úpravy
