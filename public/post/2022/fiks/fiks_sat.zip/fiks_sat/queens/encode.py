#!/usr/bin/env python3

import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common

def generate_all_points(n):
    for i in range(n):
        for j in range(n):
            yield (i, j)

def list_conflict_positions_bottom_right(p, n):
    px, py = p
    x, y = px, py
    for i in range(1, n-x):
        yield (x+i, y  )
    for i in range(1, n-y):
        yield (x  , y+i)
    for i in range(1, min(n-x, n-y)):
        yield (x+i, y+i)
    for i in range(1, min(x+1, n-y)):
        yield (x-i, y+i)

def generate_claueses(n):
    mapping = common.RangeMap([n, n])
    all_points = generate_all_points(n)
    clauses = []
    for p in all_points:
        for q in list_conflict_positions_bottom_right(p, n):
            clauses.append([-mapping.to_int(p), -mapping.to_int(q)])
    for i in range(n):
        clause = []
        for j in range(n):
            clause.append(mapping.to_int((i, j)))
        clauses.append(clause)
    return clauses

def main():
    N = int(sys.argv[1])
    clauses = generate_claueses(N)
    common.print_clauses(clauses)

if __name__ == '__main__':
    main()
