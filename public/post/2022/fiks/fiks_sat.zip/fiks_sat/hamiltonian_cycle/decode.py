#!/usr/bin/env python3

import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common

import math

result = input()
print(result)
if result != "SAT":
    exit(0)

numbers = [int(i) for i in input().split()]

n = int(math.sqrt(len(numbers)-1))

mapping = common.RangeMap([n,n])
for column in range(n):
    for x in range(n):
        idx = mapping.to_int([column, x])
        val = numbers[idx-1]
        if(val > 0):
            print(x, end=' ')
print()
