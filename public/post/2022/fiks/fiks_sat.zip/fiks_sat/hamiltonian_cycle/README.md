# Hamiltonovská kružnice

## Zadání

Najděte v grafu Hamiltonovskou kružnici.

## Vstup

Vstupem je graf. První řádek obsahuje čísla N a M, dalších M řádků popisuje hrany grafu indexované od 0.

## Výstup

Výstupem je seznam N vrcholů Hamiltonovské kružnice -- každý vrchol ne navštíven právě jednou.

## Řešení

Proměnné za to, že vrchol I je J-tým vrcholem kružnice. Hot-one pro fixní I i J přes všechny ostatní indexy. Zakázání nehran pro sousední vrcholy kružnice.

## Autoři

* Václav Blažej
