#!/usr/bin/env python3

import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common

def generate_claueses(graph):
    n = len(graph)
    mapping = common.RangeMap([n,n])
    clauses = []
    # path has exactly one vertex set to true
    for column in range(n):
        clauses += common.one_hot(list(map(lambda x:mapping.to_int([column, x]), range(n))))
    # each vertex is present in exactly one point of the path
    for x in range(n):
        clauses += common.one_hot(list(map(lambda column:mapping.to_int([column, x]), range(n))))
    for f in range(n):
        for t in range(n):
            if f not in graph[t]:
                for column_f in range(n):
                    column_t = (column_f+1) % n
                    clauses.append([-mapping.to_int([column_f, f]), -mapping.to_int([column_t, t])])
    return clauses

def main():
    graph = common.load_zero_graph()
    clauses = generate_claueses(graph)
    common.print_clauses(clauses)

if __name__ == '__main__':
    main()
