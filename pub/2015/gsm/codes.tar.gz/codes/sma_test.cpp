#include <iostream>
#include <iomanip>
#include <algorithm>    // std::shuffle
#include <random>       // std::default_random_engine
#include <string>
#include <vector>
#include <chrono>       // std::chrono::system_clock
using namespace std;

#ifndef SIGMA
#define SIGMA 26
#endif

//typedef long long unsigned int bint;
typedef unsigned int bint;
//typedef vector<int> result_t;
//#define FOUND(a) result.push_back(a)
typedef long long int result_t;
#define FOUND(a) result++
char base_char = 'A';

// GSM algorithm implementation
void gsm(string &pattern, const char *text, int p, int t, result_t &result);
//void gsm2(string &pattern, const char *text, int p, int t, result_t &result);
//void gsm3(string &pattern, const char *text, int p, int t, result_t &result);
// GSM algorithm implementation
void gsm_registers(string &pattern, const char *text, int p, int t, result_t &result);
// BP Cross Sampling implementation
void cross_sampling(string &pattern, const char *text, int p, int t, result_t &result);
// BP backward Cross Sampling implementation
void backward_cross_sampling(string &pattern, const char *text, int p, int t, result_t &result);
// Smalgoo-I implementation
void smalgo1_original (string &pattern, const char *text, int p, int t, result_t &result);
// Smalgoo-I implementation with most significant bit first
void smalgo1_msbfirst (string &pattern, const char *text, int p, int t, result_t &result);



struct Pattern{
    string pattern;
    int length;
    int lengthIdx;
};

void print_result(int algoCnt, string *labels, vector<long long int> *times, vector<int> *number_or_tests, int pattern_length_count, vector<long long int> &resCnt, vector<long long int> &max_times, vector<string> &max_pattern){
    cout<<fixed<<setprecision(4);
    for(int j = 0; j < algoCnt; ++j){
        cout<<labels[j];
        for(int k = 0; k < pattern_length_count; ++k){
            cout<<"& "<<((double)times[k][j]/1000000./number_or_tests[k][j]);
        }
        cout<<"\\\\ ";
        cout<<"MATCH:"<<resCnt[j]<<", ";
        cout<<"PAT: ";//<<max_pattern[j].length();
        for(int i = 0; i < max_pattern[j].length(); ++i){
            cout<<(char)(max_pattern[j][i]+base_char);
        }
        cout<<", TM: "<<max_times[j]<<endl;
    }
}

int main(int argc, char **argv){

    if(argc!=6){
        cout<<"usage: "<<argv[0]<<" <input file> <warmup rounds> <measure rounds> <result print period> <ping period>\n";
        return 0;
    }
    const char *input_file = argv[1];
    int warmup_rounds = atoi(argv[2]);
    int base_rounds = atoi(argv[3]);
    int result_print_period = atoi(argv[4]);
    int ping_print_period = atoi(argv[5]);

	cout << "SWAP MATCHING PROBLEM\n";
	//cout << "implemented GSM and SMALGO-I\n";
	//cout << "output positions are indexed from 1\n";
	//cout << "(Keep in mind that SMALGO-I was not built to work for patterns shorter than 3)\n";
	cout << "Input big English alphabet, first " << SIGMA << " letters, i.e.: ";
	for (int i = 0; i < SIGMA; ++i) cout << (char)(base_char+i);

	cout << "\nTEXT: ";
    string *input=new string();
    if(!freopen(input_file,"r",stdin)){
        cout<<"error while opening input file\n";
        return 1;
    }
    char buffer[1001];
    while(scanf("%1000s", buffer) == 1){
        (*input)+=(buffer);
    }
    cout<<"input loaded\n";
	int t = input->length();
    char *text = new char[t];
    copy(input->begin(), input->end(), text);
    // for non-stream situations, it suffices to prepare the text with sentinels
    //char *txt = new char[t+2]; // +2 for sentinels on each side
    //copy(input->begin(), input->end(), txt+1);
    //char *text = txt+1;
	////for(int i = 1; i < t+2; ++i){ txt[i] -= base_char; }
    //text[-1]=text[t]=text[0]; // sentinels
    //for(int i = 0; i < t+2; ++i){
    //    if(txt[i] < 0 || txt[i] >= SIGMA) {
    //        cerr<<"Invalid input: found "<<(char)(base_char+txt[i])<<" in the input\n";
    //        return 1;
    //    }
    //}
    delete input;

    int p = -1;

    srand(time(NULL));

    vector<Pattern> patterns;

    int lengths[] = {3, 4, 5, 6, 7, 8, 9, 10, 12, 16, 20, 24, 28, 32}; // uint
//    int lengths[] = {3, 4, 5, 6, 7, 8, 9, 10, 12, 16, 20, 24, 28}; // int
    int pattern_length_count = sizeof(lengths)/sizeof(lengths[0]);
    int measurement_rounds = base_rounds * pattern_length_count;
    cout << "generaing test patterns\n";
	for(int i = 0; i < base_rounds; ++i){
        for(int j = 0; j < pattern_length_count; ++j){
            int len_idx = j;
            int rnd_length = lengths[len_idx];
            int rnd_position = rand()%(t-rnd_length);
            string pattern = string(text+rnd_position, rnd_length);
            patterns.push_back({pattern, (int)pattern.length(), len_idx});
            //cout<<"generating "<<(i*pattern_length_count + j+1)<<"/"<<base_rounds*pattern_length_count<<": "<<pattern.length()<<endl;
        }
    }
    // shuffle to minimize cpu-load based time sensitive errors
    unsigned seed = chrono::system_clock::now().time_since_epoch().count();
    shuffle(patterns.begin(), patterns.end(), default_random_engine(seed));
    cout<<"picked "<<measurement_rounds<<" random substrings of the text as patterns for testing\n";


    void (*algorithms[])(string&,const char *,int,int,result_t &) = {
        smalgo1_msbfirst, cross_sampling, backward_cross_sampling, gsm/*, gsm2, gsm3*/
    };
    const int algoCnt = sizeof(algorithms)/sizeof(algorithms[0]);
    string labels[] = {"SMLG", "BPCS","BPBCS", "GSMa"/*, "GSM2", "GSM3"*/};

    vector<result_t> results(algoCnt);
    vector<long long int> max_times(algoCnt, 0);
    vector<string> max_patterns(algoCnt, "" + 0 + 0);
    vector<long long int> times[pattern_length_count];
    vector<int> number_or_tests[pattern_length_count];
    for(int j = 0; j < pattern_length_count; ++j){
        times[j] = vector<long long int>(algoCnt, 0);
        number_or_tests[j] = vector<int>(algoCnt, 0);
    }
    if(warmup_rounds) cout << "Warmup:\n";
	for(int i = 0; i < warmup_rounds; ++i){
        for(int j = 0; j < algoCnt; ++j){
            algorithms[j](patterns[0].pattern, text, patterns[0].length, t, results[j]);
        }
        if(i%20==19)cout<<"warmup ("<<i+1<<'/'<<warmup_rounds<<")\n";
    }
    vector<long long int> resCnt(algoCnt, 0);
    cout << "Testing:\n";
	for(int i = 0; i < patterns.size(); ++i){
        for(int j = 0; j < algoCnt; ++j){
            results[j]=0;
        //    results[j].clear();
        }
        Pattern &ptrn = patterns[i];
        string &patternStr = ptrn.pattern;
        int patternLen = ptrn.length;
        int patternLenIdx = ptrn.lengthIdx;
        vector<int> algoShuffle(algoCnt);
        for(int k = 0; k < algoCnt; ++k){
            algoShuffle[k] = k;
        }
        shuffle(algoShuffle.begin(), algoShuffle.end(), default_random_engine(seed));
        for(int k = 0; k < algoCnt; ++k){
            int j = algoShuffle[k];
            auto begin = chrono::high_resolution_clock::now();
            algorithms[j](patternStr, text, patternLen, t, results[j]);
            auto end = chrono::high_resolution_clock::now();
            long long int timec = chrono::duration_cast<chrono::nanoseconds>(end-begin).count();
            times[patternLenIdx][j] += timec;
            if(patternLen >= 8 && timec > max_times[j]){
                max_times[j]=timec;
                max_patterns[j] = patternStr;
            }
            number_or_tests[patternLenIdx][j]++;
        }
        // uncomment to get smalgo match discrepences
        //int error = 2;
        //int correct = 1;
        //if(results[error].size()!=results[correct].size()){
        //    for(int cor = 0, err = 0; err < results[error].size() && cor < results[correct].size(); ){
        //        if(results[correct][cor] != results[error][err]){
        //            string message, pat="", txt="";
        //            int w=patterns[i].length;
        //            for(int k = 0; k < w; ++k){ pat += (char)(patterns[i].pattern[k]+'A'); }
        //            for(int k = results[error][err]-1; k < results[error][err]+w-1; ++k){
        //                txt += (char)((text)[k]+'A');
        //            }
        //            if(results[error][err] < results[correct][cor]){
        //                message="Found";
        //                ++err;
        //            }else{
        //                message="Did not found";
        //                ++cor;
        //            }
        //            cout << message << endl;
        //            cout << "PAT: "<<pat<<endl;
        //            cout << "TXT: "<<txt<<endl;
        //        }else{
        //            ++cor;
        //            ++err;
        //        }
        //    }
        //}

        for(int j = 0; j < algoCnt; ++j){
            resCnt[j]+=results[j];
        }
        if(i % result_print_period == result_print_period - 1){
            cout<<"result for ("<<i+1<<'/'<<measurement_rounds<<"):\n";
            print_result(algoCnt, labels, times, number_or_tests, pattern_length_count, resCnt, max_times, max_patterns);
        }else if(i % ping_print_period == ping_print_period - 1){
            cout<<"measuring ("<<i+1<<'/'<<measurement_rounds<<")\n";
        }
    }

    cout<<"\n";
    cout<<"FINAL RESULT:\n\n";
    print_result(algoCnt, labels, times, number_or_tests, pattern_length_count, resCnt, max_times, max_patterns);
    //delete []txt;
}
// all measurements are in nanoseconds
// ~0.03 measurement error

void gsm(string &P, const char *T, int p, int t, result_t &result){
    const int u = 0, m = 1, d = 2;
	// DMASK initialization
	int i;
    bint F = 1;
	bint D[SIGMA];
	for(i = 0; i < SIGMA; ++i) D[i] = 0;
	for(i = 0; i < p; ++i){
		D[P[i]] |= F;
        F = F << 1;
    }

	// GSM initialization
	bint tmp[3]; // temporary vectors
	bint r[3]; // result vectors
	r[0]=r[1]=r[2]=0;
	bint resCheck = ((bint)1) << (p - 1);

	// GSM execution
	for(i = 0; i < t; ++i){
		tmp[u] = (r[d] << 1) | 1;
		tmp[m] = (r[m] << 1) | (r[u] << 1) | 1;
		tmp[d] = tmp[m];
		r[u] = tmp[u] & (D[T[i]] << 1);
		r[m] = tmp[m] &  D[T[i]];
		r[d] = tmp[d] & (D[T[i]] >> 1);
		if(((r[m] | r[u]) & resCheck) != 0) FOUND(i - p + 2);
	}
}

void cross_sampling(string &P, const char *T, int p, int t, result_t &result){
    bint F, D, E, H;
	F = 1;
    bint M[SIGMA];
    for(int c = 0; c < SIGMA; ++c) M[c]=0;
    for(int i = 0; i < p; ++i){
        M[P[i]] = M[P[i]] | F;
        F = F << 1;
    }
    F = ((bint)1) << (p - 1);
    D = E = 0;
    for(int j = 0; j < t; ++j){
        H = (D << 1) | 1;
        D = (H & M[T[j]]);
        E = (E << 1) & (j==0?0:M[T[j-1]]);
        D = D | E;
        E = H & M[T[j+1]];
        if((D & F) != 0) FOUND(j-p+1);
    }
}

void backward_cross_sampling(string &P, const char *T, int p, int t, result_t &result){
    bint F, D, C, H;
    int h, l, j;
    F = ((bint)1) << (p - 1);
    bint M[SIGMA];
    for(int c = 0; c < SIGMA; ++c) M[c]=0;
    for(int i = 0; i < p; ++i){
        M[P[i]] = M[P[i]] | F;
        F = F >> 1;
    }
    //T[t] = P[0];// is done already
    j = p - 1;
    F = ((bint)1) << (p - 1);
    while(j < t){
        h = 1; l = 0;
        D = M[T[j]] | (M[T[j+1]] & (M[T[j]] << 1));
        C = M[T[j-1]];
        while((h < p) && ((D | C) != 0)){
            if ((F & D) != 0) l = h;
            H = (C << 1) & M[T[j - h + 1]];
            C = (D << 1) & (j==h?0:M[T[j - h - 1]]);
            D = (D << 1) & M[T[j - h]];
            D = D | H;
            h = h + 1;
        }
        if(D != 0) FOUND(j-p+1);
        j = j + p - l;
    }
}

void smalgo1_original (string &pat, const char *text, int p, int t, result_t &result){
	// DMASK initialization
	bint D[SIGMA];
	for(int i =  0; i <  SIGMA; ++i)for(int j = 0; j <  p; ++j)D[i] = 0;
	for(int j =  0; j <  2; ++j) D[pat[0]]   |= (1 << (p - j - 1));
	for(int i =  1; i <  p-1; ++i) for(int j =  -1; j <  2; ++j) D[pat[i]] |= (1 << (p - j - 1 - i));
	for(int j = -1; j <  1; ++j) D[pat[p-1]] |= (1 << (p - j - 1 - (p - 1)));

	// PMASK initialization
	bint pmask[SIGMA][SIGMA][SIGMA];

	bint tmp = ((bint)1) << (p - 1);
	for(int i = 0; i < SIGMA; ++i)for(int j = 0; j < SIGMA; ++j)for(int k = 0; k < SIGMA; ++k)pmask[i][j][k] = tmp;
	for(int i =  0; i <  p - 3 + 1; ++i){pmask[pat[i]][pat[i+1]][pat[i+2]] |= (1 << (p-i-2));
		                                 pmask[pat[i]][pat[i+2]][pat[i+1]] |= (1 << (p-i-2)); }
	for(int i =  0; i <  p - 4 + 1; ++i) pmask[pat[i]][pat[i+1]][pat[i+3]] |= (1 << (p-i-2));
	for(int i =  1; i <  p - 2 + 1; ++i) pmask[pat[i]][pat[i-1]][pat[i+1]] |= (1 << (p-i-1));
	for(int i =  1; i <  p - 3 + 1; ++i) pmask[pat[i]][pat[i-1]][pat[i+2]] |= (1 << (p-i-1));
	for(int i =  0; i <  p - 4 + 1; ++i) pmask[pat[i]][pat[i+3]][pat[i+2]] |= (1 << (p-i-3));
	for(int i =  0; i <  p - 5 + 1; ++i) pmask[pat[i]][pat[i+2]][pat[i+4]] |= (1 << (p-i-3));
	for(int i =  0; i <  p - 4 + 1; ++i) pmask[pat[i]][pat[i+2]][pat[i+3]] |= (1 << (p-i-3));
	
	// SMALGO-I initialization
	bint bit = ((bint)1) << (p - 1);
	bint rj = bit & D[text[0]];
	rj = (rj >> 1) | bit;
	rj = rj & D[text[1]] & (D[text[2]] << 1);
	bint x = 2;
	int j;

	// SMALGO-I execution
	for(int k =  1; k <  t-1; ++k){
		j = k-1;
		rj = rj & pmask[text[j]][text[j+1]][text[j+2]] & D[text[j+1]] & (D[text[j+2]] << 1);
		if((rj & x) != 0) FOUND(j-p+4);
		rj = (rj >> 1) | bit;
	}
}

void smalgo1_msbfirst (string &pat, const char *text, int p, int t, result_t &result){
	// DMASK initialization
	bint D[SIGMA];
	for(int i = 0; i <  SIGMA; ++i)for(int j = 0; j <  p; ++j)D[i] = 0;
	for(int j =  0; j <  2; ++j) D[pat[0]] |= (1 << (j));
	for(int i =  1; i <  p-1; ++i) for(int j = -1; j <  2; ++j) D[pat[i]] |= (1 << (j + i));
	for(int j =  -1; j <  1; ++j) D[pat[p-1]] |= (1 << (j + (p - 1)));

	// PMASK initialization
	bint pmask[SIGMA][SIGMA][SIGMA];
	for(int i = 0; i < SIGMA; ++i)for(int j = 0; j < SIGMA; ++j)for(int k = 0; k < SIGMA; ++k)pmask[i][j][k] = 1;
	for(int i =  0; i <  p - 3 + 1; ++i){pmask[pat[i]][pat[i+1]][pat[i+2]] |= (1 << (i + 2 - 1));
		                                 pmask[pat[i]][pat[i+2]][pat[i+1]] |= (1 << (i + 2 - 1)); }
	for(int i =  0; i <  p - 4 + 1; ++i) pmask[pat[i]][pat[i+1]][pat[i+3]] |= (1 << (i + 2 - 1));
	for(int i =  1; i <  p - 2 + 1; ++i) pmask[pat[i]][pat[i-1]][pat[i+1]] |= (1 << (i + 1 - 1));
	for(int i =  1; i <  p - 3 + 1; ++i) pmask[pat[i]][pat[i-1]][pat[i+2]] |= (1 << (i + 1 - 1));
	for(int i =  0; i <  p - 4 + 1; ++i) pmask[pat[i]][pat[i+3]][pat[i+2]] |= (1 << (i + 3 - 1));
	for(int i =  0; i <  p - 5 + 1; ++i) pmask[pat[i]][pat[i+2]][pat[i+4]] |= (1 << (i + 3 - 1));
	for(int i =  0; i <  p - 4 + 1; ++i) pmask[pat[i]][pat[i+2]][pat[i+3]] |= (1 << (i + 3 - 1));
	
	// SMALGO-I initialization
	bint rj = 1 & D[text[0]];
	rj = (rj << 1) | 1;
	rj = rj & D[text[1]] & (D[text[2]] >> 1);
	bint x = (1 << (p - 2));
	int j;

	// SMALGO-I execution
	for(int k =  1; k <  t-1; ++k){
		j = k-1;
		rj = rj & pmask[text[j]][text[j+1]][text[j+2]] & D[text[j+1]] & (D[text[j+2]] >> 1);
		if((rj & x) != 0) FOUND(j-p+4);
		rj = (rj << 1) | 1;
	}
}

void gsm_registers(string &pattern, const char *text, int p, int t, result_t &result){
    const int up = 0, md = 1, dw = 2;
	// DMASK initialization
    bint F = 1;
	bint D[SIGMA];
	for(int i = 0; i < SIGMA; ++i)
		D[i] = 0;
	for(int i = 0; i < p; ++i){
		D[pattern[i]] |= F;
        F = F << 1;
    }

	// GSM initialization
	bint r[3];// result vector
	r[up] = r[md] = r[dw] = 0;
	bint tmp;
	bint resCheck = ((bint)1) << (p - 1);
	const char *textptr = &text[0];
	int counter = t;
	char symbol;

	// GSM execution - this could be implemented with (SIGMA + 8) registers with only textptr loading from RAM
	while(counter--){
		symbol = *textptr;
		r[up] = r[up] << 1;
		r[md] = r[md] << 1;
		r[dw] = r[dw] << 1;
		r[md] = r[md] | r[up];
		r[md] = r[md] | 1;
		r[up] = r[dw] | 1;
		r[dw] = r[md];
		tmp = D[symbol] << 1;
		r[up] = r[up] & tmp;
		r[md] = r[md] & D[symbol];
		tmp = D[symbol] >> 1;
		r[dw] = r[dw] & tmp;

		// check result
		tmp = r[md] | r[up];
		tmp = tmp & resCheck;
		if(tmp) FOUND(t - counter - p + 1);
		textptr++;
	}
}
