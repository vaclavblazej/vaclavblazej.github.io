#include <iostream>
#include <iomanip>
#include <algorithm>    // std::shuffle
#include <random>       // std::default_random_engine
#include <string>
#include <vector>
#include <map>
#include <set>
using namespace std;

#ifndef SIGMA
#define SIGMA 26
#endif

//typedef long long unsigned int bint;
typedef unsigned int bint;
#define FOUND(a) cout<<(a)<<endl;

// GSM algorithm implementation
void gsm(string &P, istream &ss, int p);

map<int,int> mapping;
set<char> omit;
int idx;

inline bool check(char c){
    bool res = omit.find(c) == omit.end();
    if(res){
        auto item = mapping.find(c);
        if(item == mapping.end()){
            mapping[c] = idx++;
        }
    }
    return res;
}

int main(int argc, char **argv){

    if(argc!=2){
        cout<<"usage: "<<argv[0]<<" <input file>\n";
        return 0;
    }
    const char *input_file = argv[1];

    string pattern;
    cin >> pattern;

    if(!freopen(input_file,"r",stdin)){ // send file to input stream
        cerr<<"error while opening input file\n";
        return 1;
    }

    omit.insert('\n');
    int p = pattern.length();
    int idx = 0;
    for(int i = 0; i<p; ++i){
        check(pattern[i]);
    }

    gsm(pattern, cin, p);
}

void gsm(string &P, istream &ss, int p){
    const int u = 0, m = 1, d = 2;
	// DMASK initialization
	int i = 0;
    bint F = 1;
	bint D[SIGMA];
	for(i = 0; i < SIGMA; ++i) D[i] = 0;
	for(i = 0; i < p; ++i){
		D[mapping[P[i]]] |= F;
        F = F << 1;
    }

	// GSM initialization
	bint tmp[3]; // temporary vectors
	bint r[3]; // result vectors
	r[0]=r[1]=r[2]=0;
	bint resCheck = ((bint)1) << (p - 1);

	// GSM execution
    char c;
	while(ss >> c){
        if(check(c)){
            c = mapping[c];
            tmp[u] = (r[d] << 1) | 1;
            tmp[m] = (r[m] << 1) | (r[u] << 1) | 1;
            tmp[d] = tmp[m];
            r[u] = tmp[u] & (D[c] << 1);
            r[m] = tmp[m] &  D[c];
            r[d] = tmp[d] & (D[c] >> 1);
            if(((r[m] | r[u]) & resCheck) != 0) FOUND(i - p + 2);
        }
        i++;
	}
}

