#include <iostream>

int main(){
    char c;
    while(scanf("%c", &c)==1){
        switch(c){
            case 'A': printf("A");break;
            case 'C': printf("B");break;
            case 'G': printf("C");break;
            case 'T': printf("D");break;
                      // no other character is accepted
        }
    }
}

