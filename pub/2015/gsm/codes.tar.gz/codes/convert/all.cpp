#include <iostream>
#include <map>
#include <set>
using namespace std;

int main(){
    char c;
    int idx = 0;
    map<int,int> mapping;
    set<char> omit;
    omit.insert('\n');
    while(scanf("%c", &c)==1){
        if(omit.find(c) == omit.end()){
            auto item = mapping.find(c);
            if(item == mapping.end()){
                mapping[c] = idx++;
            }
            printf("%c", mapping[c]);
        }
    }
    cerr << "Used " << idx << " different characters\n";
    for(pair<int,int> c:mapping){
        cerr<<(char)(c.first)<<' ';
    }
    cerr<<endl;
}

